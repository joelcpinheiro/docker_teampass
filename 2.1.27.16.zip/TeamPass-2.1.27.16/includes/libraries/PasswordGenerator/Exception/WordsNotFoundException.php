<?php

namespace Hackzilla\PasswordGenerator\Exception;

class WordsNotFoundException extends \Exception
{
}
