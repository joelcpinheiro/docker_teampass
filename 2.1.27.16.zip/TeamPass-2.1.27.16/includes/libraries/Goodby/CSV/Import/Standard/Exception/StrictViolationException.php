<?php

namespace Goodby\CSV\Import\Standard\Exception;

class StrictViolationException extends \RuntimeException
{
}
