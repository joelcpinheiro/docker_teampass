<?php

namespace Goodby\CSV\Import\Protocol\Exception;

/**
 * Invalid lexical Exception
 */
class InvalidLexicalException extends \RuntimeException
{
}
