<?php

use Authentication\TwoFactorAuth\TwoFactorAuthException;

class TimeException extends TwoFactorAuthException {}