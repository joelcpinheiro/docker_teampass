<?php

use Authentication\TwoFactorAuth\TwoFactorAuthException;

class RNGException extends TwoFactorAuthException {}